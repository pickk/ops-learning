"""本地 HTTP 学习服务，不用于生产。"""
import json
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent


class Handler(BaseHTTPRequestHandler):
    def respond(self, status, content_type, body):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/":
            self.respond(200, "text/html; charset=utf-8", (ROOT / "page.html").read_bytes())
            return
        if path == "/browser.js":
            self.respond(200, "text/javascript; charset=utf-8", (ROOT / "browser.js").read_bytes())
            return
        if path == "/api/servers":
            servers = [
                {"name": "web-01", "online": True},
                {"name": "db-01", "online": False}
            ]
            text = json.dumps({"servers": servers}, ensure_ascii=False)
            self.respond(200, "application/json; charset=utf-8", text.encode("utf-8"))
            return
        self.respond(404, "text/plain; charset=utf-8", "没有这个路径".encode("utf-8"))


def main():
    http = ThreadingHTTPServer(("127.0.0.1", 8091), Handler)
    print("Open http://127.0.0.1:8091")
    try:
        http.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        http.server_close()


if __name__ == "__main__":
    main()
