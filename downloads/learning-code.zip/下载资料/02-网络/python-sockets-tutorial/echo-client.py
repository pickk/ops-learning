# Adapted from Real Python materials; MIT, ../LICENSE. Modified 2026-11-08.
import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(5)
try:
    s.connect(("127.0.0.1", 65432))
    s.sendall(b"Hello, world")
    s.shutdown(socket.SHUT_WR)
    parts = []
    while True:
        data = s.recv(1024)
        if not data:
            break
        parts.append(data)
    print("Received", b"".join(parts))
finally:
    s.close()
