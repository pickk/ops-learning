# 02 Python 网络：先读懂一个 GET 接口

更新日期：2026-11-08

## 目标

知道请求怎么进入 do_GET，能独立返回一份 JSON。依据 GitHub 的 CPython HTTP 处理器源码核对调用机制。

## 只记六个概念

| 概念 | 在当前例子里是什么 |
| --- | --- |
| 客户端 | 浏览器、client.py 或 node-client.js，主动发请求 |
| 服务端 | server.py，监听端口、等待请求 |
| 地址与端口 | 127.0.0.1 是本机，8091 是学习服务监听端口 |
| 方法与路径 | GET 表示读取；/api/servers 表示读取哪项资源 |
| 状态码 | 200 成功；404 路径不存在；500 服务端错误 |
| JSON | 在客户端与服务端之间交换数据的文本格式 |

HTTP 连接、请求解析等先交给标准库。现在不用从 socket 写起。访问另一台机器时，127.0.0.1 不会指向你的服务器。

## 继承和 do_GET 到底怎么连接

```python
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        # 写自己的响应逻辑
        pass
```

父类负责读取请求并找对应方法；子类补充响应内容。Handler 可以自己命名，do_GET 是父类约定的名字。self 是当前处理器对象。

源码中的核心顺序是：把请求方法 GET 接在 do_ 后 → 得到 do_GET → 在对象中找到该方法 → 调用。源码搜索 `handle_one_request`，接着搜索 `mname` 即可；没有对应方法时默认返回 501。

```python
http = ThreadingHTTPServer(("127.0.0.1", 8091), Handler)
http.serve_forever()
```

把 Handler 这个类交给服务器，服务器会在连接到来时创建处理器；不用自己调用 do_GET。传的是 Handler，不是 Handler()。

## 返回数据的顺序

```python
text = json.dumps({"status": "ok"}, ensure_ascii=False)
body = text.encode("utf-8")
self.send_response(200)
self.send_header("Content-Type", "application/json; charset=utf-8")
self.send_header("Content-Length", str(len(body)))
self.end_headers()
self.wfile.write(body)
```

在已导入 json 的 Handler 方法内使用。先对象转 JSON 文本，再编码成字节；先状态和头，再结束头，最后写数据。Content-Length 数字节，不数汉字个数。

接收数据则反过来：字节 → decode → 文本 → json.loads → Python 对象。浏览器地址里的 #contact 不会作为路径发给服务器。

## 动手任务

打开 [server.py](examples/server.py)，读 `main → Handler.do_GET → respond`。仿照 /api/servers 分支，自己新增 /api/health，返回 `{"status": "ok"}`；浏览器直接访问核对。

再运行 [client.py](examples/client.py)：看 urlopen 发请求、read 读响应、json.loads 解析。停掉服务后再运行，应显示网络错误并以非零状态退出。

验收：能解释谁调用 do_GET，能返回 JSON，并能区分“HTTP 404”和“完全连接不上”。

## 来源、边界与待办

- [python/cpython：HTTP 处理器源码](https://github.com/python/cpython/blob/3.14/Lib/http/server.py)：只看 handle_one_request 的分派及响应方法，不通读整个文件。
- [官方服务说明](https://docs.python.org/3/library/http.server.html)：本例用于本地学习，非生产部署方案。

待办：先写通 GET，再学 POST 的消息体大小限制、输入校验和 SQLite。TCP/UDP、原始 Socket、线程细节、TLS 配置留到有需求时展开。
