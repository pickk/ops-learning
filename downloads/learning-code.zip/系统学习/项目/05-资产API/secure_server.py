"""第九单元入口；保留 server.py 供前置单元学习，不用于对外部署。"""
import argparse
import hmac
import sqlite3
import signal
import json
import sys
from http.cookies import SimpleCookie, CookieError
from urllib.parse import urlsplit
from pathlib import Path
from auth import Auth
from jobs import JobEngine
from server import Handler, AppServer
from storage import DomainError, Store


class SecureHandler(Handler):
    def log_request(self, code="-", size="-"):
        # 不记录请求体、查询串、Cookie 或 CSRF。
        print(json.dumps({"event": "http", "method": self.command, "status": code,
                          "actor": getattr(self, "actor", "anonymous")}), file=sys.stderr, flush=True)

    def serve_page(self, path):
        if self.command != "GET":
            return False
        filename = None
        media = "text/html; charset=utf-8"
        if path == "/login.js":
            filename = "login.js"
            media = "text/javascript; charset=utf-8"
        if path == "/":
            try:
                cookies = SimpleCookie(self.headers.get("Cookie", ""))
                self.server.auth.session(cookies["ops_session"].value)
            except (KeyError, CookieError, DomainError):
                filename = "login.html"
        if filename is None:
            return Handler.serve_page(self, path)
        body = (Path(__file__).parent / "web" / filename).read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", media)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)
        return True

    def end_headers(self):
        cookie = getattr(self, "response_cookie", None)
        if cookie is not None:
            self.send_header("Set-Cookie", cookie)
            self.response_cookie = None
        Handler.end_headers(self)

    def cookie_value(self, token, expired=False):
        age = 3600
        if expired:
            age = 0
        value = "ops_session=" + token + "; Path=/; HttpOnly; SameSite=Strict; Max-Age=" + str(age)
        if self.server.origin.startswith("https://"):
            value = value + "; Secure"
        return value

    def dispatch(self):
        try:
            if self.headers.get("Host") != urlsplit(self.server.origin).netloc:
                raise DomainError(400, "Host 与配置的公开地址不匹配")
            path = urlsplit(self.path).path
            write = self.command not in ["GET", "HEAD", "OPTIONS"]
            if write and self.headers.get("Origin") != self.server.origin:
                raise DomainError(403, "请求来源不匹配")
            if path == "/api/login":
                if self.command != "POST":
                    raise DomainError(405, "登录需要 POST")
                if self.headers.get("X-Requested-With") != "ops-course":
                    raise DomainError(403, "登录缺少请求标记")
                token, user = self.server.auth.login(self.read_json())
                self.response_cookie = self.cookie_value(token)
                self.reply(200, user)
                return
            if path in ["/", "/app.js", "/style.css", "/login.js", "/api/health"]:
                Handler.dispatch(self)
                return
            cookies = SimpleCookie()
            try:
                cookies.load(self.headers.get("Cookie", ""))
            except CookieError:
                raise DomainError(401, "会话 Cookie 无效")
            token = ""
            if "ops_session" in cookies:
                token = cookies["ops_session"].value
            user = self.server.auth.session(token)
            self.actor = user["username"]
            if path == "/api/audit":
                if user["role"] != "admin":
                    raise DomainError(403, "只有管理员可以查看审计")
                if self.command != "GET":
                    raise DomainError(405, "审计只支持查询")
                self.reply(200, self.server.auth.audit())
                return
            if write and not hmac.compare_digest(self.headers.get("X-CSRF-Token", "").encode("utf-8"), user["csrf"].encode("utf-8")):
                raise DomainError(403, "CSRF 校验失败")
            if path == "/api/me" and self.command == "GET":
                self.reply(200, user)
                return
            if path == "/api/logout" and self.command == "POST":
                self.server.auth.logout(token, user["username"])
                self.response_cookie = self.cookie_value("", expired=True)
                self.reply(200, {"logged_out": True})
                return
            if write:
                allowed = user["role"] == "admin"
                if path == "/api/jobs" and self.command == "POST" and user["role"] == "operator":
                    allowed = True
                if not allowed:
                    raise DomainError(403, "当前角色没有此操作权限")
            Handler.dispatch(self)
        except DomainError as error:
            self.reply(error.status, {"error": str(error)})
        except (ValueError, UnicodeError):
            self.reply(400, {"error": "输入格式无效"})
        except sqlite3.Error:
            self.reply(503, {"error": "身份数据库暂时不可用"})
        except OSError:
            self.close_connection = True


def create_secure_server(address, db_path, origin=None):
    store = Store(db_path)
    auth = Auth(store)
    server = AppServer(address, SecureHandler)
    server.store = store
    server.auth = auth
    if origin is None:
        origin = "http://127.0.0.1:" + str(server.server_port)
    parsed = urlsplit(origin)
    if parsed.scheme not in ["http", "https"] or not parsed.netloc or parsed.path or parsed.query or parsed.fragment or parsed.username or parsed.password:
        server.server_close()
        raise ValueError("origin 必须为不带路径的 http/https 来源")
    if parsed.scheme == "http" and parsed.hostname not in ["127.0.0.1", "localhost", "::1"]:
        server.server_close()
        raise ValueError("明文 HTTP 只用于本机学习")
    server.origin = origin
    try:
        server.jobs = JobEngine(store)
    except Exception:
        server.server_close()
        raise
    return server


def main():
    parser = argparse.ArgumentParser(description="带登录与角色检查的本机课程入口")
    parser.add_argument("--db", default="assets.sqlite3")
    parser.add_argument("--port", type=int, default=8096)
    parser.add_argument("--origin")
    args = parser.parse_args()
    server = create_secure_server(("127.0.0.1", args.port), args.db, args.origin)
    def stop_requested(signum, frame):
        raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM, stop_requested)
    print(server.server_port, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
