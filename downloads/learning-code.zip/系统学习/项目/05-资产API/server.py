import argparse
import json
import sqlite3
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
from storage import DomainError, Store
from jobs import JobEngine, TASKS


class Handler(BaseHTTPRequestHandler):
    def serve_page(self, path):
        files = {
            "/": ("index.html", "text/html; charset=utf-8"),
            "/app.js": ("app.js", "text/javascript; charset=utf-8"),
            "/style.css": ("style.css", "text/css; charset=utf-8")
        }
        if path not in files or self.command != "GET":
            return False
        filename, media = files[path]
        body = (Path(__file__).parent / "web" / filename).read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", media)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)
        return True

    def setup(self):
        BaseHTTPRequestHandler.setup(self)
        self.connection.settimeout(5)

    def log_message(self, message, *args):
        pass

    def reply(self, status, value):
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
            raise DomainError(415, "需要 application/json")
        lengths = self.headers.get_all("Content-Length", [])
        if len(lengths) != 1 or self.headers.get("Transfer-Encoding"):
            raise DomainError(400, "需要单个 Content-Length，不接收分块消息")
        length = int(lengths[0])
        if length < 1 or length > 8192:
            raise DomainError(413, "请求体必须为 1 到 8192 字节")
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise DomainError(400, "消息体不完整")
        return json.loads(raw.decode("utf-8"))

    def dispatch(self):
        try:
            address = urlsplit(self.path)
            path = address.path
            if self.serve_page(path):
                return
            store = self.server.store
            actor = getattr(self, "actor", "local-course")
            if path == "/api/me" and self.command == "GET":
                self.reply(200, {"username": "local-course", "role": "admin", "csrf": None})
                return
            if path == "/api/tasks" and self.command == "GET":
                self.reply(200, {"tasks": TASKS})
                return
            if path == "/api/jobs":
                if self.command == "GET":
                    self.reply(200, self.server.jobs.recent())
                elif self.command == "POST":
                    self.reply(202, self.server.jobs.submit(self.read_json(), actor))
                else:
                    raise DomainError(405, "任务列表不支持此方法")
                return
            if path.startswith("/api/jobs/"):
                part = path[len("/api/jobs/"):]
                if not part.isascii() or not part.isdigit() or len(part) > 18:
                    raise DomainError(404, "任务路径不存在")
                if self.command != "GET":
                    raise DomainError(405, "任务只能查询，不支持修改历史")
                self.reply(200, self.server.jobs.get(int(part)))
                return
            if path == "/api/health" and self.command == "GET":
                self.reply(200, {"status": "ok"})
                return
            if path == "/api/assets":
                if self.command == "GET":
                    query = parse_qs(address.query, keep_blank_values=True)
                    for key in query:
                        if key not in ["limit", "offset"] or len(query[key]) != 1:
                            raise DomainError(400, "分页参数未知或重复")
                    limit = int(query.get("limit", ["20"])[0])
                    offset = int(query.get("offset", ["0"])[0])
                    if limit < 1 or limit > 100 or offset < 0 or offset > 1000000:
                        raise DomainError(400, "分页范围错误")
                    self.reply(200, store.list_assets(limit, offset))
                elif self.command == "POST":
                    self.reply(201, store.write("create", value=self.read_json(), actor=actor))
                else:
                    raise DomainError(405, "该路径不支持此方法")
                return
            if path.startswith("/api/assets/"):
                part = path[len("/api/assets/"):]
                if not part.isascii() or not part.isdigit() or len(part) > 18:
                    raise DomainError(404, "资产路径不存在")
                asset_id = int(part)
                if self.command == "GET":
                    self.reply(200, store.get_asset(asset_id))
                elif self.command == "PUT":
                    self.reply(200, store.write("update", asset_id, self.read_json(), actor))
                elif self.command == "DELETE":
                    self.reply(200, store.write("delete", asset_id, actor=actor))
                else:
                    raise DomainError(405, "该路径不支持此方法")
                return
            raise DomainError(404, "接口不存在")
        except DomainError as error:
            self.reply(error.status, {"error": str(error)})
        except (ValueError, UnicodeError):
            self.reply(400, {"error": "输入格式无效"})
        except sqlite3.IntegrityError:
            self.reply(409, {"error": "资产名称重复或违反数据约束"})
        except sqlite3.OperationalError:
            self.reply(503, {"error": "数据库暂时不可用"})
        except sqlite3.DatabaseError:
            self.reply(500, {"error": "数据库操作失败"})
        except OSError:
            self.close_connection = True

    def do_GET(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch()

    def do_PUT(self):
        self.dispatch()

    def do_DELETE(self):
        self.dispatch()


class AppServer(ThreadingHTTPServer):
    jobs = None

    def server_close(self):
        ThreadingHTTPServer.server_close(self)
        if self.jobs is not None:
            self.jobs.close()
            self.jobs = None


def create_server(address, db_path):
    store = Store(db_path)
    server = AppServer(address, Handler)
    server.store = store
    try:
        server.jobs = JobEngine(store)
    except Exception:
        server.server_close()
        raise
    return server


def main():
    parser = argparse.ArgumentParser(description="本地资产 API")
    parser.add_argument("--db", default="assets.sqlite3")
    parser.add_argument("--port", type=int, default=8095)
    args = parser.parse_args()
    server = create_server(("127.0.0.1", args.port), args.db)
    print(server.server_port, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
